local data = SkillTreeTweakData.init
function SkillTreeTweakData:init(tweak_data)
	data(self, tweak_data)
	
table.insert(self.specializations, { --true dozer
			name_id = "TBULL_NAME",
			desc_id = "TBULL_DESC",
			{
				upgrades = {		--1
				"TBULL_AR1"
				},
				cost = 0,
				icon_xy = {0, 2},
				name_id = "TBULL_NAME_PK1",
				desc_id = "TBULL_DESC_PK1"},	
				
			{
				upgrades = {		--2
				"TBULL_AMMO1",
				"TBULL_SHOT_RELOAD",
				"TBULL_LMG_RELOAD"
					},
				cost = 0,
				icon_xy = {0, 6},
				name_id = "TBULL_NAME_PK2",
				desc_id = "TBULL_DESC_PK2"},
				
			{
				upgrades = {		--3
				"TBULL_MOVE",
				},
				cost = 0,
				icon_xy = {2, 0},
				name_id = "TBULL_NAME_PK3",
				desc_id = "TBULL_DESC_PK3"},
				
			{
				upgrades = {		--4
				"TBULL_AMMO2"
				},
				cost = 0,
				icon_xy = {0, 6},
				name_id = "TBULL_NAME_PK4",
				desc_id = "TBULL_DESC_PK4"},
				
			{
				upgrades = {		--5
				"TBULL_AR2"
				},
				cost = 0,
				icon_xy = {0, 2},
				name_id = "TBULL_NAME_PK5",
				desc_id = "TBULL_DESC_PK5"},
				
			{
				upgrades = {		--6
				"TBULL_HP"
				},
				cost = 0,
				icon_xy = {0, 0},
				name_id = "TBULL_NAME_PK6",
				desc_id = "TBULL_DESC_PK6"},
				
			{
				upgrades = {		--7
				"TBULL_SHOT_DMG",
				"TBULL_LMG_DMG"
				},
				cost = 0,
				icon_xy = {1, 1},
				name_id = "TBULL_NAME_PK7",
				desc_id = "TBULL_DESC_PK7"},
				
			{
				upgrades = {		--8
				"TBULL_SHOT_RATE",
				"TBULL_LMG_RATE"
				},
				cost = 0,
				icon_xy = {1, 1},
				name_id = "TBULL_NAME_PK8",
				desc_id = "TBULL_DESC_PK8"},
				
			{
				upgrades = {		--9
				"TBULL_AR3"
				},
				cost = 0,
				icon_xy = {0, 5},
				name_id = "TBULL_NAME_PK9",
				desc_id = "TBULL_DESC_PK9"}
	})


table.insert(self.specializations, { --WotEtoDaYT
			name_id = "OPM_NAME",
			desc_id = "OPM_DESC",
			{
				upgrades = {		--1
				"OPM_MOVE1"
				},
				cost = 0,
				icon_xy = {2, 0},
				name_id = "OPM_NAME_PK1",
				desc_id = "OPM_DESC_PK1"},	
				
			{
				upgrades = {		--2
				"OPM_AR1"
					},
				cost = 0,
				icon_xy = {0, 2},
				name_id = "OPM_NAME_PK2",
				desc_id = "OPM_DESC_PK2"},
				
			{
				upgrades = {		--3
				"OPM_HP1",
				},
				cost = 0,
				icon_xy = {0, 0},
				name_id = "OPM_NAME_PK3",
				desc_id = "OPM_DESC_PK3"},
				
			{
				upgrades = {		--4
				"OPM_BLUNT1"
				},
				cost = 0,
				icon_xy = {0, 5},
				name_id = "OPM_NAME_PK4",
				desc_id = "OPM_DESC_PK4"},
				
			{
				upgrades = {		--5
				"OPM_MOVE2"
				},
				cost = 0,
				icon_xy = {2, 0},
				name_id = "OPM_NAME_PK5",
				desc_id = "OPM_DESC_PK5"},
				
			{
				upgrades = {		--6
				"OPM_AR2"
				},
				cost = 0,
				icon_xy = {0, 2},
				name_id = "OPM_NAME_PK6",
				desc_id = "OPM_DESC_PK6"},
				
			{
				upgrades = {		--7
				"OPM_H2"
				},
				cost = 0,
				icon_xy = {0, 0},
				name_id = "OPM_NAME_PK7",
				desc_id = "OPM_DESC_PK7"},
				
			{
				upgrades = {		--8
				"OPM_BLUNT2"
				},
				cost = 0,
				icon_xy = {0, 5},
				name_id = "OPM_NAME_PK8",
				desc_id = "OPM_DESC_PK8"},
				
			{
				upgrades = {		--9
				"OPM_ARREGEN"
				},
				cost = 0,
				icon_xy = {0, 6},
				name_id = "OPM_NAME_PK9",
				desc_id = "OPM_DESC_PK9"}
	})
	
end