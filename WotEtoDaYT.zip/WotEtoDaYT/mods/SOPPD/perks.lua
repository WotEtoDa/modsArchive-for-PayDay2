local data = UpgradesTweakData._init_pd2_values
function UpgradesTweakData:_init_pd2_values()
data(self, tweak_data)

	self.values.player.tier_armor_multiplier = {2, 5, 10, 2, 50 }
	self.values.player.passive_health_multiplier = { 2, 2, 50 }
	self.values.player.armor_regen_timer_multiplier_passive = { 0 }
	
	self.values.player.extra_ammo_multiplier = { 2, 5 }
	
	self.values.player.movement_speed_multiplier = {1.5, 1.5, 2.5}
	
	self.values.shotgun.damage_multiplier = {2}
	self.values.lmg.damage_multiplier = {2}
	self.values.player.melee_blunt_damage_multiplier = {2, 9999}
	
	self.values.shotgun.fire_rate_multiplier = {2}
	self.values.lmg.fire_rate_multiplier = {2}
	
	self.values.shotgun.reload_speed_multiplier = {2}
	self.values.lmg.reload_speed_multiplier = {2}
end


local skills = UpgradesTweakData._player_definitions
function UpgradesTweakData:_player_definitions()
skills(self, tweak_data)
	
	--True Dozer
	self.definitions.TBULL_AR1 = {
		category = "feature",
		name_id = "menu_player_tier_armor_multiplier",
		upgrade = {
			category = "player",
			upgrade = "tier_armor_multiplier",
			value = 1}}	
	self.definitions.TBULL_AR2 = {
		category = "feature",
		name_id = "menu_player_tier_armor_multiplier",
		upgrade = {
			category = "player",
			upgrade = "tier_armor_multiplier",
			value = 2}}	
	self.definitions.TBULL_AR3 = {
		category = "feature",
		name_id = "menu_player_tier_armor_multiplier",
		upgrade = {
			category = "player",
			upgrade = "tier_armor_multiplier",
			value = 3}}			
	self.definitions.TBULL_HP = {
		category = "feature",
		name_id = "menu_player_passive_health_multiplier",
		upgrade = {
			category = "player",
			upgrade = "passive_health_multiplier",
			value = 1}}
	self.definitions.TBULL_AMMO1 = {
		category = "feature",
		name_id = "menu_player_extra_ammo_multiplier",
		upgrade = {
			category = "player",
			upgrade = "extra_ammo_multiplier",
			value = 1}}	
	self.definitions.TBULL_AMMO2 = {
		category = "feature",
		name_id = "menu_player_extra_ammo_multiplier",
		upgrade = {
			category = "player",
			upgrade = "extra_ammo_multiplier",
			value = 2}}	
	self.definitions.TBULL_MOVE = {
		category = "feature",
		name_id = "menu_player_movement_speed_multiplier",
		upgrade = {
			category = "player",
			upgrade = "movement_speed_multiplier",
			value = 1}}
	self.definitions.TBULL_SHOT_DMG = {
		category = "feature",
		name_id = "menu_shotgun_damage_multiplier",
		upgrade = {
			category = "shotgun",
			upgrade = "damage_multiplier",
			value = 1}}	
	self.definitions.TBULL_LMG_DMG = {
		category = "feature",
		name_id = "menu_lmg_damage_multiplier",
		upgrade = {
			category = "lmg",
			upgrade = "damage_multiplier",
			value = 1}}	
	self.definitions.TBULL_SHOT_RATE = {
		category = "feature",
		name_id = "menu_shotgun_fire_rate_multiplier",
		upgrade = {
			category = "shotgun",
			upgrade = "fire_rate_multiplier",
			value = 1}}
	self.definitions.TBULL_LMG_RATE = {
		category = "feature",
		name_id = "menu_lmg_fire_rate_multiplier",
		upgrade = {
			category = "lmg",
			upgrade = "fire_rate_multiplier",
			value = 1}}
	self.definitions.TBULL_SHOT_RELOAD = {
		category = "feature",
		name_id = "menu_shotgun_reload_speed_multiplier",
		upgrade = {
			category = "shotgun",
			upgrade = "reload_speed_multiplier",
			value = 1}}
	self.definitions.TBULL_LMG_RELOAD = {
		category = "feature",
		name_id = "menu_lmg_reload_speed_multiplier",
		upgrade = {
			category = "lmg",
			upgrade = "reload_speed_multiplier",
			value = 1}}

			
	--WotEtoDaYT
	self.definitions.OPM_MOVE1 = {
		category = "feature",
		name_id = "menu_player_movement_speed_multiplier",
		upgrade = {
			category = "player",
			upgrade = "movement_speed_multiplier",
			value = 2}}
	self.definitions.OPM_MOVE2 = {
		category = "feature",
		name_id = "menu_player_movement_speed_multiplier",
		upgrade = {
			category = "player",
			upgrade = "movement_speed_multiplier",
			value = 3}}
	
	self.definitions.OPM_AR1 = {
		category = "feature",
		name_id = "menu_player_tier_armor_multiplier",
		upgrade = {
			category = "player",
			upgrade = "tier_armor_multiplier",
			value = 4}}	
	self.definitions.OPM_AR2 = {
		category = "feature",
		name_id = "menu_player_tier_armor_multiplier",
		upgrade = {
			category = "player",
			upgrade = "tier_armor_multiplier",
			value = 5}}	

	self.definitions.OPM_HP1 = {
		category = "feature",
		name_id = "menu_player_passive_health_multiplier",
		upgrade = {
			category = "player",
			upgrade = "passive_health_multiplier",
			value = 2}}
	self.definitions.OPM_HP2 = {
		category = "feature",
		name_id = "menu_player_passive_health_multiplier",
		upgrade = {
			category = "player",
			upgrade = "passive_health_multiplier",
			value = 3}}
	
	self.definitions.OPM_BLUNT1 = {
		category = "feature",
		name_id = "menu_player_melee_blunt_damage_multiplier",
		upgrade = {
			category = "player",
			upgrade = "melee_blunt_damage_multiplier",
			value = 1}}
	self.definitions.OPM_BLUNT2 = {
		category = "feature",
		name_id = "menu_player_melee_blunt_damage_multiplier",
		upgrade = {
			category = "player",
			upgrade = "melee_blunt_damage_multiplier",
			value = 2}}
			
	self.definitions.OPM_ARREGEN = {
		category = "feature",
		name_id = "menu_player_armor_regen_timer_multiplier_passive",
		upgrade = {
			category = "player",
			upgrade = "armor_regen_timer_multiplier_passive",
			value = 1}}
	
	
	
end