function AchievmentManager:award(id, ...)
	return
end
function AchievmentManager:award_progress(stat, value, ...)
	return
end
