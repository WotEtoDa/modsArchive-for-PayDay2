payday2-god
-----------
Payday 2 mod to toggle god mode.

Requires
--------
BLT 2.0+ (r6_r16) or later
- https://github.com/JamesWilko/Payday-2-BLT/releases/tag/2.0

Installation
------------
- Copy to mods directory after setting up BLT.
- Setup hotkeys for BLT.

Notes
-----
Payday 2, Update 93+ (2015-12-18)
