function WinSteamDLCManager:_check_dlc_data(dlc_data)
    return true
end
function WinEpicDLCManager:_check_dlc_data(dlc_data)
    return true
end
function WINDLCManager:_check_dlc_data(dlc_data)
    return true
end
